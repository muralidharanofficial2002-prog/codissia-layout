# SUBCON 2027 · Figma canvas & prototype

This package creates native, editable Figma design pages for the SUBCON 2027 app in `muralidharanofficial2002-prog/codissia-layout` (source commit `3a3fccb6c70174a8c4dc30c157b596e308920ea5`). It does not modify the app or the published cloud environment.

## Create the canvas in Figma

1. Extract the ZIP into a local folder. Open a **Figma Design file in the Figma desktop app**.
2. Open **Plugins → Development → Import plugin from manifest…** and select this folder's `manifest.json`.
3. Run **SUBCON 2027 · Full canvas & prototype** from the Development plugins menu. Allow a little time for fonts, images and layers to be created.
4. Open **03 · Desktop · 1440** or **04 · Mobile · 390**, select the Home frame, and press **Present**. Both pages have a named prototype starting flow.

If your Figma version requires a generated plugin ID to import a development manifest, use **Plugins → Development → New plugin**, choose a Figma Design **Run once** plugin, and open its generated folder. Copy this package's `code.js` there. Keep Figma's generated `id`, set `main` to `code.js`, and add `documentAccess: "dynamic-page"` and `networkAccess: {"allowedDomains": ["none"]}` to that generated manifest. Run the new development plugin. No account token or network access is required.

The plugin **adds five pages**. It preserves existing pages and content. Running it twice adds another set; use Undo immediately if you want to remove a run. It does not publish a library or change sharing permissions.

## Canvas contents

- **01 · Foundations & guide:** color variables, local paint/text styles, spacing tokens, typography, scope and usage notes, plus full-length native desktop and mobile landing layouts for canvas inspection.
- **02 · UI components:** native component sets for buttons, input states, filter chips, bookmarks, radio options, capacity indicators, workshop/process/exhibitor/stat cards, navigation, registration status, accordion and toast states. Includes auto layout, editable vector icons and interactive variants.
- **03 · Desktop · 1440:** full landing page and connected desktop interaction states.
- **04 · Mobile · 390:** responsive landing page, mobile navigation and connected mobile interaction states.
- **05 · Prototype flow map:** discovery, capability selection, workshop itinerary, registration and exhibitor journeys.

The screens follow the app's current charcoal, cyan and orange brand, use the actual repository content, and embed its photography and logo. Desktop prototype viewports are 1440×1000; mobile viewports are 390×844. Tall content scrolls vertically in Present. Preferred fonts are Host Grotesk and Instrument Serif; the plugin falls back to Inter/Georgia when necessary.

## Prototype interactions

- Home navigation and section exploration.
- Manufacturing processes, parts and visitor tabs, with process-specific capability details.
- Workshop day filters, saved-session views, bookmark examples and an empty-result state.
- Registration empty/filled/error states, role/interest choices, and buyer/manufacturer/visitor delegate passes.
- Exhibition scene switching, innovation image states and company-specific exhibitor lightboxes.
- Native component state changes such as hover, focus examples, selection, expansion and bookmarking.

Figma uses staged screen states for forms and itinerary examples. It does **not** run React, accept arbitrary form input, submit registrations or preserve every possible combination of filter/bookmark state. Sample personal details are fictional. Photos remain image fills; text, UI, icons and containers are editable. Videos use posters/scene states, and the website's live sonar/scroll physics are represented visually. The brochure screen is a resource preview, not an embedded PDF reader.

## Review and verification

`preview.html` is a self-contained, offline visual preview with an artboard selector and clickable routes. Its typography/layout approximate the native scene. It is not a `.fig` file and is not a substitute for Figma playback.

The generator has been executed in a local scene-model harness to check native components/instances, image bytes, reaction targets, screen reachability, return paths, artboard overlaps and text bounds. `validation-report.json` records the resulting counts and checks. Actual import/playback in Figma is still required; this session has no callable Figma integration, so no remote Figma file URL has been created.

All plugin assets are embedded. The manifest requests no network access. No credential is included or needed. Existing application files and cloud configuration are unchanged.
